import 'package:flutter/material.dart';

class ThemeConstant {
  ThemeConstant._();
  static const Color darkPrimaryColor = Colors.lightBlue;
  static const Color primaryColor = Colors.lightBlue;
  static const Color appBarColor = Colors.lightBlue;
}
